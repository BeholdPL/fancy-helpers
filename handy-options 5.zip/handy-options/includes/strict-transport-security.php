<?php

header('Strict-Transport-Security: max-age=31536000;');