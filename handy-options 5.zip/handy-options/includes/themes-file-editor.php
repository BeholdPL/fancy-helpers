<?php

define('DISALLOW_FILE_EDIT', true);