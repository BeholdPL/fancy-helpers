<?php

header('Referrer-Policy: same-origin');