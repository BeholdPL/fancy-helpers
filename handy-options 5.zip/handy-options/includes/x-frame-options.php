<?php

header('X-Frame-Options: SAMEORIGIN');