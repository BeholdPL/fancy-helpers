<?php

header("Permissions-Policy: accelerometer=(), autoplay=(), camera=(), encrypted-media=(), geolocation=(), gyroscope=(), magnetometer=(), microphone=(), sync-xhr=(), usb=(), fullscreen=(), picture-in-picture=()");