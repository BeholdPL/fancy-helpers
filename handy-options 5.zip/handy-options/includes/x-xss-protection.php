<?php

header('X-XSS-Protection: 1; mode=block');