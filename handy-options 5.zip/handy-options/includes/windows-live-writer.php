<?php

remove_action('wp_head', 'wlwmanifest_link');