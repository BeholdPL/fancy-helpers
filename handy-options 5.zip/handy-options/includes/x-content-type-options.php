<?php

header('X-Content-Type-Options: nosniff');